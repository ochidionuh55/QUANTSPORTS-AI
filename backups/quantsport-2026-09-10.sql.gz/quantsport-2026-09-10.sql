--
-- PostgreSQL database dump
--

\restrict IXkcCBDhDMjuvYup8hJ0P8fIuWcAhG0mHwUO615A86Jj0gENoqTmPkbvgFHDECH

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.wallet_transactions DROP CONSTRAINT fk_wallet_transactions_user_id_users;
ALTER TABLE ONLY public.wallet_transactions DROP CONSTRAINT fk_wallet_transactions_parent_transaction_id_wallet_tra_5fb2;
ALTER TABLE ONLY public.user_preferences DROP CONSTRAINT fk_user_preferences_user_id_users;
ALTER TABLE ONLY public.user_feedback DROP CONSTRAINT fk_user_feedback_user_id_users;
ALTER TABLE ONLY public.teams DROP CONSTRAINT fk_teams_competition_id_competitions;
ALTER TABLE ONLY public.team_aliases DROP CONSTRAINT fk_team_aliases_team_id_teams;
ALTER TABLE ONLY public.scans DROP CONSTRAINT fk_scans_user_id_users;
ALTER TABLE ONLY public.scans DROP CONSTRAINT fk_scans_model_version_id_model_versions;
ALTER TABLE ONLY public.saved_fixtures DROP CONSTRAINT fk_saved_fixtures_user_id_users;
ALTER TABLE ONLY public.predictions DROP CONSTRAINT fk_predictions_tradeable_snapshot_id_odds_snapshots;
ALTER TABLE ONLY public.predictions DROP CONSTRAINT fk_predictions_scan_id_scans;
ALTER TABLE ONLY public.predictions DROP CONSTRAINT fk_predictions_reference_snapshot_id_odds_snapshots;
ALTER TABLE ONLY public.predictions DROP CONSTRAINT fk_predictions_outcome_id_outcomes;
ALTER TABLE ONLY public.predictions DROP CONSTRAINT fk_predictions_model_version_id_model_versions;
ALTER TABLE ONLY public.predictions DROP CONSTRAINT fk_predictions_match_id_matches;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT fk_outcomes_market_id_markets;
ALTER TABLE ONLY public.odds_snapshots DROP CONSTRAINT fk_odds_snapshots_outcome_id_outcomes;
ALTER TABLE ONLY public.matches DROP CONSTRAINT fk_matches_home_team_id_teams;
ALTER TABLE ONLY public.matches DROP CONSTRAINT fk_matches_competition_id_competitions;
ALTER TABLE ONLY public.matches DROP CONSTRAINT fk_matches_away_team_id_teams;
ALTER TABLE ONLY public.markets DROP CONSTRAINT fk_markets_match_id_matches;
ALTER TABLE ONLY public.historical_matches DROP CONSTRAINT fk_historical_matches_home_team_id_teams;
ALTER TABLE ONLY public.historical_matches DROP CONSTRAINT fk_historical_matches_competition_id_competitions;
ALTER TABLE ONLY public.historical_matches DROP CONSTRAINT fk_historical_matches_away_team_id_teams;
ALTER TABLE ONLY public.fixture_views DROP CONSTRAINT fk_fixture_views_user_id_users;
ALTER TABLE ONLY public.booking_codes DROP CONSTRAINT fk_booking_codes_user_id_users;
ALTER TABLE ONLY public.booking_codes DROP CONSTRAINT fk_booking_codes_scan_id_scans;
DROP INDEX public.ix_wallet_transactions_user_id_created_at;
DROP INDEX public.ix_wallet_transactions_state;
DROP INDEX public.ix_wallet_transactions_parent_transaction_id;
DROP INDEX public.ix_wallet_transactions_created_at;
DROP INDEX public.ix_users_last_seen_at;
DROP INDEX public.ix_user_feedback_user;
DROP INDEX public.ix_user_feedback_fixture;
DROP INDEX public.ix_user_feedback_created_at;
DROP INDEX public.ix_teams_normalized_name;
DROP INDEX public.ix_teams_competition_id;
DROP INDEX public.ix_team_aliases_team_id;
DROP INDEX public.ix_team_aliases_review_status;
DROP INDEX public.ix_team_aliases_external_team_id;
DROP INDEX public.ix_stored_analyses_kickoff;
DROP INDEX public.ix_stored_analyses_coverage;
DROP INDEX public.ix_settled_predictions_source;
DROP INDEX public.ix_settled_predictions_kickoff;
DROP INDEX public.ix_settled_predictions_coverage;
DROP INDEX public.ix_settled_predictions_competition;
DROP INDEX public.ix_scans_user_id_created_at;
DROP INDEX public.ix_scans_status;
DROP INDEX public.ix_scans_model_version_id;
DROP INDEX public.ix_saved_fixtures_user;
DROP INDEX public.ix_predictions_tradeable_snapshot_id;
DROP INDEX public.ix_predictions_scan_id_rank;
DROP INDEX public.ix_predictions_reference_snapshot_id;
DROP INDEX public.ix_predictions_outcome_id;
DROP INDEX public.ix_predictions_model_version_id;
DROP INDEX public.ix_predictions_match_id;
DROP INDEX public.ix_predictions_created_at;
DROP INDEX public.ix_outcomes_staleness;
DROP INDEX public.ix_odds_snapshots_provider_role_snapshot_type;
DROP INDEX public.ix_odds_snapshots_outcome_id_captured_at;
DROP INDEX public.ix_model_versions_status;
DROP INDEX public.ix_matches_status_start_time;
DROP INDEX public.ix_matches_start_time;
DROP INDEX public.ix_matches_modellability;
DROP INDEX public.ix_matches_home_team_id;
DROP INDEX public.ix_matches_competition_id;
DROP INDEX public.ix_matches_away_team_id;
DROP INDEX public.ix_historical_matches_match_date;
DROP INDEX public.ix_historical_matches_home_team_id_match_date;
DROP INDEX public.ix_historical_matches_competition_id;
DROP INDEX public.ix_historical_matches_away_team_id_match_date;
DROP INDEX public.ix_fixture_views_user_created;
DROP INDEX public.ix_fixture_views_fixture;
DROP INDEX public.ix_fixture_views_created_at;
DROP INDEX public.ix_dataset_ingestions_lookup;
DROP INDEX public.ix_dataset_ingestions_created_at;
DROP INDEX public.ix_dataset_ingestions_content_hash;
DROP INDEX public.ix_competitions_has_historical_coverage;
DROP INDEX public.ix_booking_codes_user_id_created_at;
DROP INDEX public.ix_booking_codes_status;
DROP INDEX public.ix_booking_codes_scan_id;
ALTER TABLE ONLY public.wallet_transactions DROP CONSTRAINT uq_wallet_transactions_user_id_idempotency_key;
ALTER TABLE ONLY public.users DROP CONSTRAINT uq_users_telegram_id;
ALTER TABLE ONLY public.user_preferences DROP CONSTRAINT uq_user_preferences_user;
ALTER TABLE ONLY public.teams DROP CONSTRAINT uq_teams_sport_country_normalized_name;
ALTER TABLE ONLY public.team_aliases DROP CONSTRAINT uq_team_aliases_provider_normalized_alias;
ALTER TABLE ONLY public.stored_analyses DROP CONSTRAINT uq_stored_analyses_provider_event;
ALTER TABLE ONLY public.settled_predictions DROP CONSTRAINT uq_settled_predictions_provider_event;
ALTER TABLE ONLY public.scans DROP CONSTRAINT uq_scans_user_id_idempotency_key;
ALTER TABLE ONLY public.saved_fixtures DROP CONSTRAINT uq_saved_fixtures_user_fixture;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT uq_outcomes_market_id_provider_outcome_id;
ALTER TABLE ONLY public.model_versions DROP CONSTRAINT uq_model_versions_name_version;
ALTER TABLE ONLY public.matches DROP CONSTRAINT uq_matches_provider_name_event_id;
ALTER TABLE ONLY public.markets DROP CONSTRAINT uq_markets_match_id_provider_market_id_specifier;
ALTER TABLE ONLY public.historical_matches DROP CONSTRAINT uq_historical_matches_provider_name_provider_match_id;
ALTER TABLE ONLY public.competitions DROP CONSTRAINT uq_competitions_sport_country_name;
ALTER TABLE ONLY public.booking_codes DROP CONSTRAINT uq_booking_codes_user_id_idempotency_key;
ALTER TABLE ONLY public.wallet_transactions DROP CONSTRAINT pk_wallet_transactions;
ALTER TABLE ONLY public.users DROP CONSTRAINT pk_users;
ALTER TABLE ONLY public.user_preferences DROP CONSTRAINT pk_user_preferences;
ALTER TABLE ONLY public.user_feedback DROP CONSTRAINT pk_user_feedback;
ALTER TABLE ONLY public.teams DROP CONSTRAINT pk_teams;
ALTER TABLE ONLY public.team_aliases DROP CONSTRAINT pk_team_aliases;
ALTER TABLE ONLY public.stored_analyses DROP CONSTRAINT pk_stored_analyses;
ALTER TABLE ONLY public.settled_predictions DROP CONSTRAINT pk_settled_predictions;
ALTER TABLE ONLY public.scans DROP CONSTRAINT pk_scans;
ALTER TABLE ONLY public.saved_fixtures DROP CONSTRAINT pk_saved_fixtures;
ALTER TABLE ONLY public.predictions DROP CONSTRAINT pk_predictions;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT pk_outcomes;
ALTER TABLE ONLY public.odds_snapshots DROP CONSTRAINT pk_odds_snapshots;
ALTER TABLE ONLY public.model_versions DROP CONSTRAINT pk_model_versions;
ALTER TABLE ONLY public.matches DROP CONSTRAINT pk_matches;
ALTER TABLE ONLY public.markets DROP CONSTRAINT pk_markets;
ALTER TABLE ONLY public.historical_matches DROP CONSTRAINT pk_historical_matches;
ALTER TABLE ONLY public.fixture_views DROP CONSTRAINT pk_fixture_views;
ALTER TABLE ONLY public.dataset_ingestions DROP CONSTRAINT pk_dataset_ingestions;
ALTER TABLE ONLY public.competitions DROP CONSTRAINT pk_competitions;
ALTER TABLE ONLY public.booking_codes DROP CONSTRAINT pk_booking_codes;
ALTER TABLE ONLY public.alembic_version DROP CONSTRAINT alembic_version_pkc;
ALTER TABLE public.wallet_transactions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_preferences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_feedback ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.teams ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.team_aliases ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.stored_analyses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.settled_predictions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.scans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.saved_fixtures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.predictions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.outcomes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.odds_snapshots ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.model_versions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.matches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.markets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.historical_matches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fixture_views ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dataset_ingestions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.competitions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.booking_codes ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.wallet_transactions_id_seq;
DROP TABLE public.wallet_transactions;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.user_preferences_id_seq;
DROP TABLE public.user_preferences;
DROP SEQUENCE public.user_feedback_id_seq;
DROP TABLE public.user_feedback;
DROP SEQUENCE public.teams_id_seq;
DROP TABLE public.teams;
DROP SEQUENCE public.team_aliases_id_seq;
DROP TABLE public.team_aliases;
DROP SEQUENCE public.stored_analyses_id_seq;
DROP TABLE public.stored_analyses;
DROP SEQUENCE public.settled_predictions_id_seq;
DROP TABLE public.settled_predictions;
DROP SEQUENCE public.scans_id_seq;
DROP TABLE public.scans;
DROP SEQUENCE public.saved_fixtures_id_seq;
DROP TABLE public.saved_fixtures;
DROP SEQUENCE public.predictions_id_seq;
DROP TABLE public.predictions;
DROP SEQUENCE public.outcomes_id_seq;
DROP TABLE public.outcomes;
DROP SEQUENCE public.odds_snapshots_id_seq;
DROP TABLE public.odds_snapshots;
DROP SEQUENCE public.model_versions_id_seq;
DROP TABLE public.model_versions;
DROP SEQUENCE public.matches_id_seq;
DROP TABLE public.matches;
DROP SEQUENCE public.markets_id_seq;
DROP TABLE public.markets;
DROP SEQUENCE public.historical_matches_id_seq;
DROP TABLE public.historical_matches;
DROP SEQUENCE public.fixture_views_id_seq;
DROP TABLE public.fixture_views;
DROP SEQUENCE public.dataset_ingestions_id_seq;
DROP TABLE public.dataset_ingestions;
DROP SEQUENCE public.competitions_id_seq;
DROP TABLE public.competitions;
DROP SEQUENCE public.booking_codes_id_seq;
DROP TABLE public.booking_codes;
DROP TABLE public.alembic_version;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: booking_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_codes (
    user_id bigint NOT NULL,
    scan_id bigint,
    provider_name character varying(64) NOT NULL,
    booking_code character varying(64),
    share_url text,
    status character varying(21) NOT NULL,
    selections jsonb DEFAULT '{}'::jsonb NOT NULL,
    unavailable_selections jsonb DEFAULT '{}'::jsonb NOT NULL,
    expiry_time timestamp with time zone,
    idempotency_key character varying(128),
    error_message text,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_booking_codes_booking_code_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'active'::character varying, 'expired'::character varying, 'failed'::character varying, 'partially_unavailable'::character varying])::text[])))
);


--
-- Name: booking_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.booking_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: booking_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.booking_codes_id_seq OWNED BY public.booking_codes.id;


--
-- Name: competitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.competitions (
    canonical_name character varying(160) NOT NULL,
    normalized_name character varying(160) NOT NULL,
    country character varying(80),
    sport character varying(32) NOT NULL,
    tier integer,
    has_historical_coverage boolean DEFAULT false NOT NULL,
    external_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: competitions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.competitions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: competitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.competitions_id_seq OWNED BY public.competitions.id;


--
-- Name: dataset_ingestions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataset_ingestions (
    provider_name character varying(64) NOT NULL,
    source_name character varying(128) NOT NULL,
    source_url text,
    competition_external_id character varying(64) NOT NULL,
    season character varying(16) NOT NULL,
    content_hash character varying(64) NOT NULL,
    parser_version character varying(32) NOT NULL,
    schema_version character varying(64) NOT NULL,
    row_count integer NOT NULL,
    inserted_count integer NOT NULL,
    skipped_count integer NOT NULL,
    rejected_count integer NOT NULL,
    unresolved_team_count integer NOT NULL,
    teams_created integer NOT NULL,
    aliases_created integer NOT NULL,
    rejections jsonb DEFAULT '{}'::jsonb NOT NULL,
    downloaded_at timestamp with time zone,
    ingested_at timestamp with time zone NOT NULL,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: dataset_ingestions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dataset_ingestions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_ingestions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dataset_ingestions_id_seq OWNED BY public.dataset_ingestions.id;


--
-- Name: fixture_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fixture_views (
    user_id bigint NOT NULL,
    provider_event_id character varying(128) NOT NULL,
    home_name character varying(128) NOT NULL,
    away_name character varying(128) NOT NULL,
    competition character varying(128),
    kickoff timestamp with time zone,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: fixture_views_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fixture_views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fixture_views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fixture_views_id_seq OWNED BY public.fixture_views.id;


--
-- Name: historical_matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.historical_matches (
    provider_name character varying(64) NOT NULL,
    provider_match_id character varying(128) NOT NULL,
    home_team_id bigint NOT NULL,
    away_team_id bigint NOT NULL,
    competition_id bigint,
    season character varying(16),
    match_date date NOT NULL,
    home_goals integer NOT NULL,
    away_goals integer NOT NULL,
    half_time_home_goals integer,
    half_time_away_goals integer,
    data_version character varying(64) NOT NULL,
    ingested_at timestamp with time zone NOT NULL,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_historical_matches_goals_non_negative CHECK (((home_goals >= 0) AND (away_goals >= 0))),
    CONSTRAINT ck_historical_matches_teams_differ CHECK ((home_team_id <> away_team_id))
);


--
-- Name: historical_matches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.historical_matches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: historical_matches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.historical_matches_id_seq OWNED BY public.historical_matches.id;


--
-- Name: markets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.markets (
    match_id bigint NOT NULL,
    provider_market_id character varying(64) NOT NULL,
    market_name character varying(128) NOT NULL,
    specifier character varying(64),
    status character varying(9) NOT NULL,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_markets_outcome_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'suspended'::character varying, 'settled'::character varying, 'removed'::character varying])::text[])))
);


--
-- Name: markets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.markets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: markets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.markets_id_seq OWNED BY public.markets.id;


--
-- Name: matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matches (
    provider_name character varying(64) NOT NULL,
    provider_event_id character varying(128) NOT NULL,
    sport character varying(32) NOT NULL,
    home_team_id bigint,
    away_team_id bigint,
    home_team_raw character varying(160) NOT NULL,
    away_team_raw character varying(160) NOT NULL,
    competition_id bigint,
    competition_raw character varying(160),
    country character varying(80),
    start_time timestamp with time zone NOT NULL,
    status character varying(9) NOT NULL,
    modellability character varying(22) NOT NULL,
    modellability_note text,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_matches_match_status CHECK (((status)::text = ANY ((ARRAY['scheduled'::character varying, 'live'::character varying, 'finished'::character varying, 'postponed'::character varying, 'cancelled'::character varying, 'unknown'::character varying])::text[]))),
    CONSTRAINT ck_matches_modellability_status CHECK (((modellability)::text = ANY ((ARRAY['modellable'::character varying, 'no_historical_coverage'::character varying, 'unresolved_teams'::character varying, 'insufficient_matches'::character varying, 'unsupported_sport'::character varying])::text[])))
);


--
-- Name: matches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matches_id_seq OWNED BY public.matches.id;


--
-- Name: model_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_versions (
    name character varying(96) NOT NULL,
    version character varying(32) NOT NULL,
    status character varying(9) NOT NULL,
    margin_method character varying(12) NOT NULL,
    ensemble_method character varying(18) NOT NULL,
    configuration jsonb DEFAULT '{}'::jsonb NOT NULL,
    feature_set jsonb DEFAULT '{}'::jsonb NOT NULL,
    validation_metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    training_start date,
    training_end date,
    validation_start date,
    validation_end date,
    test_start date,
    test_end date,
    promoted_at timestamp with time zone,
    promotion_note text,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_model_versions_ensemble_method CHECK (((ensemble_method)::text = ANY ((ARRAY['market_only'::character varying, 'log_odds_shrinkage'::character varying, 'bayesian_update'::character varying, 'residual_model'::character varying, 'weighted_average'::character varying])::text[]))),
    CONSTRAINT ck_model_versions_margin_method CHECK (((margin_method)::text = ANY ((ARRAY['proportional'::character varying, 'power'::character varying, 'shin'::character varying])::text[]))),
    CONSTRAINT ck_model_versions_model_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'training'::character varying, 'validated'::character varying, 'promoted'::character varying, 'retired'::character varying, 'rejected'::character varying])::text[]))),
    CONSTRAINT ck_model_versions_training_precedes_test CHECK (((training_end IS NULL) OR (test_start IS NULL) OR (training_end < test_start))),
    CONSTRAINT ck_model_versions_validation_precedes_test CHECK (((validation_end IS NULL) OR (test_start IS NULL) OR (validation_end < test_start)))
);


--
-- Name: model_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_versions_id_seq OWNED BY public.model_versions.id;


--
-- Name: odds_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.odds_snapshots (
    outcome_id bigint NOT NULL,
    provider_name character varying(64) NOT NULL,
    provider_role character varying(9) NOT NULL,
    odds numeric(10,3) NOT NULL,
    snapshot_type character varying(7) NOT NULL,
    captured_at timestamp with time zone NOT NULL,
    source_timestamp timestamp with time zone,
    id bigint NOT NULL,
    CONSTRAINT ck_odds_snapshots_odds_exceed_stake CHECK ((odds > (1)::numeric)),
    CONSTRAINT ck_odds_snapshots_provider_role CHECK (((provider_role)::text = ANY ((ARRAY['reference'::character varying, 'tradeable'::character varying])::text[]))),
    CONSTRAINT ck_odds_snapshots_snapshot_type CHECK (((snapshot_type)::text = ANY ((ARRAY['opening'::character varying, 'interim'::character varying, 'closing'::character varying])::text[])))
);


--
-- Name: odds_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.odds_snapshots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: odds_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.odds_snapshots_id_seq OWNED BY public.odds_snapshots.id;


--
-- Name: outcomes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outcomes (
    market_id bigint NOT NULL,
    provider_outcome_id character varying(64) NOT NULL,
    outcome_name character varying(128) NOT NULL,
    odds numeric(10,3) NOT NULL,
    status character varying(9) NOT NULL,
    last_fetched_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    staleness character varying(7) NOT NULL,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_outcomes_odds_exceed_stake CHECK ((odds > (1)::numeric)),
    CONSTRAINT ck_outcomes_outcome_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'suspended'::character varying, 'settled'::character varying, 'removed'::character varying])::text[]))),
    CONSTRAINT ck_outcomes_staleness_status CHECK (((staleness)::text = ANY ((ARRAY['fresh'::character varying, 'stale'::character varying, 'expired'::character varying])::text[])))
);


--
-- Name: outcomes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.outcomes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: outcomes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.outcomes_id_seq OWNED BY public.outcomes.id;


--
-- Name: predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.predictions (
    scan_id bigint NOT NULL,
    match_id bigint NOT NULL,
    outcome_id bigint,
    model_version_id bigint NOT NULL,
    tradeable_snapshot_id bigint,
    reference_snapshot_id bigint,
    market_name character varying(128) NOT NULL,
    selection character varying(128) NOT NULL,
    specifier character varying(64),
    odds numeric(10,3) NOT NULL,
    margin_method character varying(12) NOT NULL,
    raw_market_probability numeric(9,8) NOT NULL,
    market_prior_probability numeric(9,8) NOT NULL,
    model_probability numeric(9,8) NOT NULL,
    final_probability numeric(9,8) NOT NULL,
    edge numeric(9,8) NOT NULL,
    expected_value numeric(14,8) NOT NULL,
    confidence_score numeric(5,2),
    risk_score numeric(5,2),
    rank integer,
    feature_values jsonb DEFAULT '{}'::jsonb NOT NULL,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_predictions_confidence_score_in_range CHECK (((confidence_score IS NULL) OR ((confidence_score >= (0)::numeric) AND (confidence_score <= (100)::numeric)))),
    CONSTRAINT ck_predictions_final_probability_in_range CHECK (((final_probability > (0)::numeric) AND (final_probability < (1)::numeric))),
    CONSTRAINT ck_predictions_margin_method CHECK (((margin_method)::text = ANY ((ARRAY['proportional'::character varying, 'power'::character varying, 'shin'::character varying])::text[]))),
    CONSTRAINT ck_predictions_odds_exceed_stake CHECK ((odds > (1)::numeric)),
    CONSTRAINT ck_predictions_prior_in_range CHECK (((market_prior_probability > (0)::numeric) AND (market_prior_probability < (1)::numeric)))
);


--
-- Name: predictions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.predictions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: predictions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.predictions_id_seq OWNED BY public.predictions.id;


--
-- Name: saved_fixtures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_fixtures (
    user_id bigint NOT NULL,
    provider_event_id character varying(128) NOT NULL,
    home_name character varying(128) NOT NULL,
    away_name character varying(128) NOT NULL,
    competition character varying(128),
    kickoff timestamp with time zone,
    note text,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: saved_fixtures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.saved_fixtures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: saved_fixtures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.saved_fixtures_id_seq OWNED BY public.saved_fixtures.id;


--
-- Name: scans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scans (
    user_id bigint NOT NULL,
    model_version_id bigint,
    scan_type character varying(12) NOT NULL,
    mode character varying(12) NOT NULL,
    status character varying(14) NOT NULL,
    credits_reserved integer DEFAULT 0 NOT NULL,
    credits_used integer DEFAULT 0 NOT NULL,
    matches_scanned integer DEFAULT 0 NOT NULL,
    matches_unmodellable integer DEFAULT 0 NOT NULL,
    outcomes_scanned integer DEFAULT 0 NOT NULL,
    window_start timestamp with time zone,
    window_end timestamp with time zone,
    idempotency_key character varying(128),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_scans_credits_non_negative CHECK (((credits_reserved >= 0) AND (credits_used >= 0))),
    CONSTRAINT ck_scans_scan_mode CHECK (((mode)::text = ANY ((ARRAY['conservative'::character varying, 'balanced'::character varying, 'aggressive'::character varying, 'research'::character varying])::text[]))),
    CONSTRAINT ck_scans_scan_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'running'::character varying, 'completed'::character varying, 'failed'::character varying, 'no_opportunity'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT ck_scans_scan_type CHECK (((scan_type)::text = ANY ((ARRAY['today'::character varying, 'next_24h'::character varying, 'next_48h'::character varying, 'custom_range'::character varying])::text[]))),
    CONSTRAINT ck_scans_usage_within_reservation CHECK ((credits_used <= credits_reserved))
);


--
-- Name: scans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scans_id_seq OWNED BY public.scans.id;


--
-- Name: settled_predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settled_predictions (
    provider_name character varying(64) NOT NULL,
    provider_event_id character varying(128) NOT NULL,
    home_name character varying(128) NOT NULL,
    away_name character varying(128) NOT NULL,
    competition character varying(128),
    kickoff timestamp with time zone NOT NULL,
    coverage character varying(24) NOT NULL,
    model_version character varying(64) NOT NULL,
    components_used jsonb DEFAULT '[]'::jsonb NOT NULL,
    predicted_home double precision NOT NULL,
    predicted_draw double precision NOT NULL,
    predicted_away double precision NOT NULL,
    predicted_over_2_5 double precision,
    predicted_btts double precision,
    expected_home_goals double precision,
    expected_away_goals double precision,
    market_home double precision,
    market_draw double precision,
    market_away double precision,
    home_goals integer NOT NULL,
    away_goals integer NOT NULL,
    actual_result character varying(8) NOT NULL,
    predicted_favourite character varying(8) NOT NULL,
    favourite_won boolean DEFAULT false NOT NULL,
    over_2_5_hit boolean,
    btts_hit boolean,
    settled_at timestamp with time zone NOT NULL,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source character varying(16) DEFAULT 'live'::character varying NOT NULL
);


--
-- Name: settled_predictions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settled_predictions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settled_predictions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settled_predictions_id_seq OWNED BY public.settled_predictions.id;


--
-- Name: stored_analyses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stored_analyses (
    provider_name character varying(64) NOT NULL,
    provider_event_id character varying(128) NOT NULL,
    home_name character varying(128) NOT NULL,
    away_name character varying(128) NOT NULL,
    competition character varying(128),
    country character varying(64),
    kickoff timestamp with time zone NOT NULL,
    coverage character varying(24) NOT NULL,
    unavailable_reason text,
    markets jsonb DEFAULT '{}'::jsonb NOT NULL,
    expected_home_goals double precision,
    expected_away_goals double precision,
    market_odds jsonb,
    market_probabilities jsonb,
    home_stats jsonb DEFAULT '{}'::jsonb NOT NULL,
    away_stats jsonb DEFAULT '{}'::jsonb NOT NULL,
    components_used jsonb DEFAULT '[]'::jsonb NOT NULL,
    components_dropped jsonb DEFAULT '[]'::jsonb NOT NULL,
    computed_at timestamp with time zone NOT NULL,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    provenance jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: stored_analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stored_analyses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stored_analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stored_analyses_id_seq OWNED BY public.stored_analyses.id;


--
-- Name: team_aliases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_aliases (
    team_id bigint NOT NULL,
    provider_name character varying(64) NOT NULL,
    alias character varying(160) NOT NULL,
    normalized_alias character varying(160) NOT NULL,
    external_team_id character varying(128),
    match_confidence numeric(5,4),
    review_status character varying(18) NOT NULL,
    is_confirmed boolean DEFAULT false NOT NULL,
    review_note text,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_team_aliases_match_confidence_is_a_probability CHECK (((match_confidence IS NULL) OR ((match_confidence >= (0)::numeric) AND (match_confidence <= (1)::numeric)))),
    CONSTRAINT ck_team_aliases_review_status CHECK (((review_status)::text = ANY ((ARRAY['auto_confirmed'::character varying, 'manually_confirmed'::character varying, 'pending_review'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: team_aliases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.team_aliases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team_aliases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.team_aliases_id_seq OWNED BY public.team_aliases.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    canonical_name character varying(160) NOT NULL,
    normalized_name character varying(160) NOT NULL,
    short_name character varying(64),
    country character varying(80),
    sport character varying(32) NOT NULL,
    competition_id bigint,
    external_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: user_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_feedback (
    user_id bigint NOT NULL,
    provider_event_id character varying(64),
    feature character varying(32) NOT NULL,
    verdict character varying(16) NOT NULL,
    comment text,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_feedback_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_feedback_id_seq OWNED BY public.user_feedback.id;


--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_preferences (
    user_id bigint NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_preferences_id_seq OWNED BY public.user_preferences.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    telegram_id bigint NOT NULL,
    username character varying(64),
    first_name character varying(128),
    language_code character varying(16),
    credits integer DEFAULT 0 NOT NULL,
    plan character varying(8) DEFAULT 'free'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    age_confirmed_at timestamp with time zone,
    terms_accepted_at timestamp with time zone,
    last_seen_at timestamp with time zone,
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    accepted_terms_version character varying(16),
    CONSTRAINT ck_users_credits_non_negative CHECK ((credits >= 0)),
    CONSTRAINT ck_users_user_plan CHECK (((plan)::text = ANY ((ARRAY['free'::character varying, 'standard'::character varying, 'premium'::character varying])::text[])))
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallet_transactions (
    user_id bigint NOT NULL,
    amount integer NOT NULL,
    balance_before integer NOT NULL,
    balance_after integer NOT NULL,
    transaction_type character varying(16) NOT NULL,
    state character varying(9) NOT NULL,
    parent_transaction_id bigint,
    description text,
    reference character varying(128),
    idempotency_key character varying(128),
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_wallet_transactions_balance_after_non_negative CHECK ((balance_after >= 0)),
    CONSTRAINT ck_wallet_transactions_balance_arithmetic_consistent CHECK ((balance_after = (balance_before + amount))),
    CONSTRAINT ck_wallet_transactions_transaction_state CHECK (((state)::text = ANY ((ARRAY['reserved'::character varying, 'completed'::character varying, 'released'::character varying, 'failed'::character varying])::text[]))),
    CONSTRAINT ck_wallet_transactions_transaction_type CHECK (((transaction_type)::text = ANY ((ARRAY['signup_bonus'::character varying, 'purchase'::character varying, 'admin_adjustment'::character varying, 'scan_reservation'::character varying, 'scan_settlement'::character varying, 'scan_release'::character varying, 'booking_code'::character varying, 'refund'::character varying])::text[])))
);


--
-- Name: wallet_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wallet_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wallet_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wallet_transactions_id_seq OWNED BY public.wallet_transactions.id;


--
-- Name: booking_codes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_codes ALTER COLUMN id SET DEFAULT nextval('public.booking_codes_id_seq'::regclass);


--
-- Name: competitions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitions ALTER COLUMN id SET DEFAULT nextval('public.competitions_id_seq'::regclass);


--
-- Name: dataset_ingestions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset_ingestions ALTER COLUMN id SET DEFAULT nextval('public.dataset_ingestions_id_seq'::regclass);


--
-- Name: fixture_views id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixture_views ALTER COLUMN id SET DEFAULT nextval('public.fixture_views_id_seq'::regclass);


--
-- Name: historical_matches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_matches ALTER COLUMN id SET DEFAULT nextval('public.historical_matches_id_seq'::regclass);


--
-- Name: markets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.markets ALTER COLUMN id SET DEFAULT nextval('public.markets_id_seq'::regclass);


--
-- Name: matches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches ALTER COLUMN id SET DEFAULT nextval('public.matches_id_seq'::regclass);


--
-- Name: model_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_versions ALTER COLUMN id SET DEFAULT nextval('public.model_versions_id_seq'::regclass);


--
-- Name: odds_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.odds_snapshots ALTER COLUMN id SET DEFAULT nextval('public.odds_snapshots_id_seq'::regclass);


--
-- Name: outcomes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes ALTER COLUMN id SET DEFAULT nextval('public.outcomes_id_seq'::regclass);


--
-- Name: predictions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions ALTER COLUMN id SET DEFAULT nextval('public.predictions_id_seq'::regclass);


--
-- Name: saved_fixtures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_fixtures ALTER COLUMN id SET DEFAULT nextval('public.saved_fixtures_id_seq'::regclass);


--
-- Name: scans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans ALTER COLUMN id SET DEFAULT nextval('public.scans_id_seq'::regclass);


--
-- Name: settled_predictions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settled_predictions ALTER COLUMN id SET DEFAULT nextval('public.settled_predictions_id_seq'::regclass);


--
-- Name: stored_analyses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_analyses ALTER COLUMN id SET DEFAULT nextval('public.stored_analyses_id_seq'::regclass);


--
-- Name: team_aliases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_aliases ALTER COLUMN id SET DEFAULT nextval('public.team_aliases_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: user_feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_feedback ALTER COLUMN id SET DEFAULT nextval('public.user_feedback_id_seq'::regclass);


--
-- Name: user_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_preferences_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: wallet_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions ALTER COLUMN id SET DEFAULT nextval('public.wallet_transactions_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
c5184dc0b3e7
\.


--
-- Data for Name: booking_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.booking_codes (user_id, scan_id, provider_name, booking_code, share_url, status, selections, unavailable_selections, expiry_time, idempotency_key, error_message, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: competitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.competitions (canonical_name, normalized_name, country, sport, tier, has_historical_coverage, external_metadata, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dataset_ingestions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataset_ingestions (provider_name, source_name, source_url, competition_external_id, season, content_hash, parser_version, schema_version, row_count, inserted_count, skipped_count, rejected_count, unresolved_team_count, teams_created, aliases_created, rejections, downloaded_at, ingested_at, id, created_at) FROM stdin;
\.


--
-- Data for Name: fixture_views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fixture_views (user_id, provider_event_id, home_name, away_name, competition, kickoff, id, created_at) FROM stdin;
\.


--
-- Data for Name: historical_matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.historical_matches (provider_name, provider_match_id, home_team_id, away_team_id, competition_id, season, match_date, home_goals, away_goals, half_time_home_goals, half_time_away_goals, data_version, ingested_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: markets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.markets (match_id, provider_market_id, market_name, specifier, status, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matches (provider_name, provider_event_id, sport, home_team_id, away_team_id, home_team_raw, away_team_raw, competition_id, competition_raw, country, start_time, status, modellability, modellability_note, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: model_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_versions (name, version, status, margin_method, ensemble_method, configuration, feature_set, validation_metrics, training_start, training_end, validation_start, validation_end, test_start, test_end, promoted_at, promotion_note, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: odds_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.odds_snapshots (outcome_id, provider_name, provider_role, odds, snapshot_type, captured_at, source_timestamp, id) FROM stdin;
\.


--
-- Data for Name: outcomes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outcomes (market_id, provider_outcome_id, outcome_name, odds, status, last_fetched_at, expires_at, staleness, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.predictions (scan_id, match_id, outcome_id, model_version_id, tradeable_snapshot_id, reference_snapshot_id, market_name, selection, specifier, odds, margin_method, raw_market_probability, market_prior_probability, model_probability, final_probability, edge, expected_value, confidence_score, risk_score, rank, feature_values, id, created_at) FROM stdin;
\.


--
-- Data for Name: saved_fixtures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_fixtures (user_id, provider_event_id, home_name, away_name, competition, kickoff, note, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scans (user_id, model_version_id, scan_type, mode, status, credits_reserved, credits_used, matches_scanned, matches_unmodellable, outcomes_scanned, window_start, window_end, idempotency_key, started_at, completed_at, error_message, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: settled_predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settled_predictions (provider_name, provider_event_id, home_name, away_name, competition, kickoff, coverage, model_version, components_used, predicted_home, predicted_draw, predicted_away, predicted_over_2_5, predicted_btts, expected_home_goals, expected_away_goals, market_home, market_draw, market_away, home_goals, away_goals, actual_result, predicted_favourite, favourite_won, over_2_5_hit, btts_hit, settled_at, id, created_at, updated_at, source) FROM stdin;
\.


--
-- Data for Name: stored_analyses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stored_analyses (provider_name, provider_event_id, home_name, away_name, competition, country, kickoff, coverage, unavailable_reason, markets, expected_home_goals, expected_away_goals, market_odds, market_probabilities, home_stats, away_stats, components_used, components_dropped, computed_at, id, created_at, updated_at, provenance) FROM stdin;
\.


--
-- Data for Name: team_aliases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.team_aliases (team_id, provider_name, alias, normalized_alias, external_team_id, match_confidence, review_status, is_confirmed, review_note, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teams (canonical_name, normalized_name, short_name, country, sport, competition_id, external_metadata, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_feedback (user_id, provider_event_id, feature, verdict, comment, id, created_at) FROM stdin;
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_preferences (user_id, settings, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (telegram_id, username, first_name, language_code, credits, plan, is_active, is_admin, is_blocked, age_confirmed_at, terms_accepted_at, last_seen_at, id, created_at, updated_at, accepted_terms_version) FROM stdin;
\.


--
-- Data for Name: wallet_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wallet_transactions (user_id, amount, balance_before, balance_after, transaction_type, state, parent_transaction_id, description, reference, idempotency_key, id, created_at) FROM stdin;
\.


--
-- Name: booking_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.booking_codes_id_seq', 1, false);


--
-- Name: competitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.competitions_id_seq', 1, false);


--
-- Name: dataset_ingestions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dataset_ingestions_id_seq', 1, false);


--
-- Name: fixture_views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fixture_views_id_seq', 1, false);


--
-- Name: historical_matches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.historical_matches_id_seq', 1, false);


--
-- Name: markets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.markets_id_seq', 1, false);


--
-- Name: matches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matches_id_seq', 1, false);


--
-- Name: model_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_versions_id_seq', 1, false);


--
-- Name: odds_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.odds_snapshots_id_seq', 1, false);


--
-- Name: outcomes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.outcomes_id_seq', 1, false);


--
-- Name: predictions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.predictions_id_seq', 1, false);


--
-- Name: saved_fixtures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.saved_fixtures_id_seq', 1, false);


--
-- Name: scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scans_id_seq', 1, false);


--
-- Name: settled_predictions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settled_predictions_id_seq', 1, false);


--
-- Name: stored_analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stored_analyses_id_seq', 1, false);


--
-- Name: team_aliases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.team_aliases_id_seq', 1, false);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.teams_id_seq', 1, false);


--
-- Name: user_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_feedback_id_seq', 1, false);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_preferences_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: wallet_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wallet_transactions_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: booking_codes pk_booking_codes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_codes
    ADD CONSTRAINT pk_booking_codes PRIMARY KEY (id);


--
-- Name: competitions pk_competitions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitions
    ADD CONSTRAINT pk_competitions PRIMARY KEY (id);


--
-- Name: dataset_ingestions pk_dataset_ingestions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset_ingestions
    ADD CONSTRAINT pk_dataset_ingestions PRIMARY KEY (id);


--
-- Name: fixture_views pk_fixture_views; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixture_views
    ADD CONSTRAINT pk_fixture_views PRIMARY KEY (id);


--
-- Name: historical_matches pk_historical_matches; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_matches
    ADD CONSTRAINT pk_historical_matches PRIMARY KEY (id);


--
-- Name: markets pk_markets; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.markets
    ADD CONSTRAINT pk_markets PRIMARY KEY (id);


--
-- Name: matches pk_matches; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT pk_matches PRIMARY KEY (id);


--
-- Name: model_versions pk_model_versions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_versions
    ADD CONSTRAINT pk_model_versions PRIMARY KEY (id);


--
-- Name: odds_snapshots pk_odds_snapshots; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.odds_snapshots
    ADD CONSTRAINT pk_odds_snapshots PRIMARY KEY (id);


--
-- Name: outcomes pk_outcomes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT pk_outcomes PRIMARY KEY (id);


--
-- Name: predictions pk_predictions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT pk_predictions PRIMARY KEY (id);


--
-- Name: saved_fixtures pk_saved_fixtures; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_fixtures
    ADD CONSTRAINT pk_saved_fixtures PRIMARY KEY (id);


--
-- Name: scans pk_scans; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT pk_scans PRIMARY KEY (id);


--
-- Name: settled_predictions pk_settled_predictions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settled_predictions
    ADD CONSTRAINT pk_settled_predictions PRIMARY KEY (id);


--
-- Name: stored_analyses pk_stored_analyses; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_analyses
    ADD CONSTRAINT pk_stored_analyses PRIMARY KEY (id);


--
-- Name: team_aliases pk_team_aliases; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_aliases
    ADD CONSTRAINT pk_team_aliases PRIMARY KEY (id);


--
-- Name: teams pk_teams; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT pk_teams PRIMARY KEY (id);


--
-- Name: user_feedback pk_user_feedback; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_feedback
    ADD CONSTRAINT pk_user_feedback PRIMARY KEY (id);


--
-- Name: user_preferences pk_user_preferences; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT pk_user_preferences PRIMARY KEY (id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- Name: wallet_transactions pk_wallet_transactions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT pk_wallet_transactions PRIMARY KEY (id);


--
-- Name: booking_codes uq_booking_codes_user_id_idempotency_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_codes
    ADD CONSTRAINT uq_booking_codes_user_id_idempotency_key UNIQUE (user_id, idempotency_key);


--
-- Name: competitions uq_competitions_sport_country_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitions
    ADD CONSTRAINT uq_competitions_sport_country_name UNIQUE (sport, country, normalized_name);


--
-- Name: historical_matches uq_historical_matches_provider_name_provider_match_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_matches
    ADD CONSTRAINT uq_historical_matches_provider_name_provider_match_id UNIQUE (provider_name, provider_match_id);


--
-- Name: markets uq_markets_match_id_provider_market_id_specifier; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.markets
    ADD CONSTRAINT uq_markets_match_id_provider_market_id_specifier UNIQUE (match_id, provider_market_id, specifier);


--
-- Name: matches uq_matches_provider_name_event_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT uq_matches_provider_name_event_id UNIQUE (provider_name, provider_event_id);


--
-- Name: model_versions uq_model_versions_name_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_versions
    ADD CONSTRAINT uq_model_versions_name_version UNIQUE (name, version);


--
-- Name: outcomes uq_outcomes_market_id_provider_outcome_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT uq_outcomes_market_id_provider_outcome_id UNIQUE (market_id, provider_outcome_id);


--
-- Name: saved_fixtures uq_saved_fixtures_user_fixture; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_fixtures
    ADD CONSTRAINT uq_saved_fixtures_user_fixture UNIQUE (user_id, provider_event_id);


--
-- Name: scans uq_scans_user_id_idempotency_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT uq_scans_user_id_idempotency_key UNIQUE (user_id, idempotency_key);


--
-- Name: settled_predictions uq_settled_predictions_provider_event; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settled_predictions
    ADD CONSTRAINT uq_settled_predictions_provider_event UNIQUE (provider_name, provider_event_id);


--
-- Name: stored_analyses uq_stored_analyses_provider_event; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_analyses
    ADD CONSTRAINT uq_stored_analyses_provider_event UNIQUE (provider_name, provider_event_id);


--
-- Name: team_aliases uq_team_aliases_provider_normalized_alias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_aliases
    ADD CONSTRAINT uq_team_aliases_provider_normalized_alias UNIQUE (provider_name, normalized_alias);


--
-- Name: teams uq_teams_sport_country_normalized_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT uq_teams_sport_country_normalized_name UNIQUE (sport, country, normalized_name);


--
-- Name: user_preferences uq_user_preferences_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT uq_user_preferences_user UNIQUE (user_id);


--
-- Name: users uq_users_telegram_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_telegram_id UNIQUE (telegram_id);


--
-- Name: wallet_transactions uq_wallet_transactions_user_id_idempotency_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT uq_wallet_transactions_user_id_idempotency_key UNIQUE (user_id, idempotency_key);


--
-- Name: ix_booking_codes_scan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_booking_codes_scan_id ON public.booking_codes USING btree (scan_id);


--
-- Name: ix_booking_codes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_booking_codes_status ON public.booking_codes USING btree (status);


--
-- Name: ix_booking_codes_user_id_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_booking_codes_user_id_created_at ON public.booking_codes USING btree (user_id, created_at);


--
-- Name: ix_competitions_has_historical_coverage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_competitions_has_historical_coverage ON public.competitions USING btree (has_historical_coverage);


--
-- Name: ix_dataset_ingestions_content_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dataset_ingestions_content_hash ON public.dataset_ingestions USING btree (content_hash);


--
-- Name: ix_dataset_ingestions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dataset_ingestions_created_at ON public.dataset_ingestions USING btree (created_at);


--
-- Name: ix_dataset_ingestions_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dataset_ingestions_lookup ON public.dataset_ingestions USING btree (competition_external_id, season, created_at);


--
-- Name: ix_fixture_views_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fixture_views_created_at ON public.fixture_views USING btree (created_at);


--
-- Name: ix_fixture_views_fixture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fixture_views_fixture ON public.fixture_views USING btree (provider_event_id);


--
-- Name: ix_fixture_views_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fixture_views_user_created ON public.fixture_views USING btree (user_id, created_at);


--
-- Name: ix_historical_matches_away_team_id_match_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_historical_matches_away_team_id_match_date ON public.historical_matches USING btree (away_team_id, match_date);


--
-- Name: ix_historical_matches_competition_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_historical_matches_competition_id ON public.historical_matches USING btree (competition_id);


--
-- Name: ix_historical_matches_home_team_id_match_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_historical_matches_home_team_id_match_date ON public.historical_matches USING btree (home_team_id, match_date);


--
-- Name: ix_historical_matches_match_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_historical_matches_match_date ON public.historical_matches USING btree (match_date);


--
-- Name: ix_matches_away_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matches_away_team_id ON public.matches USING btree (away_team_id);


--
-- Name: ix_matches_competition_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matches_competition_id ON public.matches USING btree (competition_id);


--
-- Name: ix_matches_home_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matches_home_team_id ON public.matches USING btree (home_team_id);


--
-- Name: ix_matches_modellability; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matches_modellability ON public.matches USING btree (modellability);


--
-- Name: ix_matches_start_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matches_start_time ON public.matches USING btree (start_time);


--
-- Name: ix_matches_status_start_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matches_status_start_time ON public.matches USING btree (status, start_time);


--
-- Name: ix_model_versions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_model_versions_status ON public.model_versions USING btree (status);


--
-- Name: ix_odds_snapshots_outcome_id_captured_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_odds_snapshots_outcome_id_captured_at ON public.odds_snapshots USING btree (outcome_id, captured_at);


--
-- Name: ix_odds_snapshots_provider_role_snapshot_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_odds_snapshots_provider_role_snapshot_type ON public.odds_snapshots USING btree (provider_role, snapshot_type);


--
-- Name: ix_outcomes_staleness; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_outcomes_staleness ON public.outcomes USING btree (staleness);


--
-- Name: ix_predictions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_created_at ON public.predictions USING btree (created_at);


--
-- Name: ix_predictions_match_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_match_id ON public.predictions USING btree (match_id);


--
-- Name: ix_predictions_model_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_model_version_id ON public.predictions USING btree (model_version_id);


--
-- Name: ix_predictions_outcome_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_outcome_id ON public.predictions USING btree (outcome_id);


--
-- Name: ix_predictions_reference_snapshot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_reference_snapshot_id ON public.predictions USING btree (reference_snapshot_id);


--
-- Name: ix_predictions_scan_id_rank; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_scan_id_rank ON public.predictions USING btree (scan_id, rank);


--
-- Name: ix_predictions_tradeable_snapshot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_tradeable_snapshot_id ON public.predictions USING btree (tradeable_snapshot_id);


--
-- Name: ix_saved_fixtures_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_saved_fixtures_user ON public.saved_fixtures USING btree (user_id);


--
-- Name: ix_scans_model_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scans_model_version_id ON public.scans USING btree (model_version_id);


--
-- Name: ix_scans_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scans_status ON public.scans USING btree (status);


--
-- Name: ix_scans_user_id_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scans_user_id_created_at ON public.scans USING btree (user_id, created_at);


--
-- Name: ix_settled_predictions_competition; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_settled_predictions_competition ON public.settled_predictions USING btree (competition);


--
-- Name: ix_settled_predictions_coverage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_settled_predictions_coverage ON public.settled_predictions USING btree (coverage);


--
-- Name: ix_settled_predictions_kickoff; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_settled_predictions_kickoff ON public.settled_predictions USING btree (kickoff);


--
-- Name: ix_settled_predictions_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_settled_predictions_source ON public.settled_predictions USING btree (source);


--
-- Name: ix_stored_analyses_coverage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stored_analyses_coverage ON public.stored_analyses USING btree (coverage);


--
-- Name: ix_stored_analyses_kickoff; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stored_analyses_kickoff ON public.stored_analyses USING btree (kickoff);


--
-- Name: ix_team_aliases_external_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_team_aliases_external_team_id ON public.team_aliases USING btree (provider_name, external_team_id);


--
-- Name: ix_team_aliases_review_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_team_aliases_review_status ON public.team_aliases USING btree (review_status);


--
-- Name: ix_team_aliases_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_team_aliases_team_id ON public.team_aliases USING btree (team_id);


--
-- Name: ix_teams_competition_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_teams_competition_id ON public.teams USING btree (competition_id);


--
-- Name: ix_teams_normalized_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_teams_normalized_name ON public.teams USING btree (normalized_name);


--
-- Name: ix_user_feedback_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_feedback_created_at ON public.user_feedback USING btree (created_at);


--
-- Name: ix_user_feedback_fixture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_feedback_fixture ON public.user_feedback USING btree (provider_event_id);


--
-- Name: ix_user_feedback_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_feedback_user ON public.user_feedback USING btree (user_id);


--
-- Name: ix_users_last_seen_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_last_seen_at ON public.users USING btree (last_seen_at);


--
-- Name: ix_wallet_transactions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wallet_transactions_created_at ON public.wallet_transactions USING btree (created_at);


--
-- Name: ix_wallet_transactions_parent_transaction_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wallet_transactions_parent_transaction_id ON public.wallet_transactions USING btree (parent_transaction_id);


--
-- Name: ix_wallet_transactions_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wallet_transactions_state ON public.wallet_transactions USING btree (state);


--
-- Name: ix_wallet_transactions_user_id_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wallet_transactions_user_id_created_at ON public.wallet_transactions USING btree (user_id, created_at);


--
-- Name: booking_codes fk_booking_codes_scan_id_scans; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_codes
    ADD CONSTRAINT fk_booking_codes_scan_id_scans FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: booking_codes fk_booking_codes_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_codes
    ADD CONSTRAINT fk_booking_codes_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fixture_views fk_fixture_views_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixture_views
    ADD CONSTRAINT fk_fixture_views_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: historical_matches fk_historical_matches_away_team_id_teams; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_matches
    ADD CONSTRAINT fk_historical_matches_away_team_id_teams FOREIGN KEY (away_team_id) REFERENCES public.teams(id) ON DELETE RESTRICT;


--
-- Name: historical_matches fk_historical_matches_competition_id_competitions; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_matches
    ADD CONSTRAINT fk_historical_matches_competition_id_competitions FOREIGN KEY (competition_id) REFERENCES public.competitions(id) ON DELETE SET NULL;


--
-- Name: historical_matches fk_historical_matches_home_team_id_teams; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_matches
    ADD CONSTRAINT fk_historical_matches_home_team_id_teams FOREIGN KEY (home_team_id) REFERENCES public.teams(id) ON DELETE RESTRICT;


--
-- Name: markets fk_markets_match_id_matches; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.markets
    ADD CONSTRAINT fk_markets_match_id_matches FOREIGN KEY (match_id) REFERENCES public.matches(id) ON DELETE CASCADE;


--
-- Name: matches fk_matches_away_team_id_teams; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT fk_matches_away_team_id_teams FOREIGN KEY (away_team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- Name: matches fk_matches_competition_id_competitions; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT fk_matches_competition_id_competitions FOREIGN KEY (competition_id) REFERENCES public.competitions(id) ON DELETE SET NULL;


--
-- Name: matches fk_matches_home_team_id_teams; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT fk_matches_home_team_id_teams FOREIGN KEY (home_team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- Name: odds_snapshots fk_odds_snapshots_outcome_id_outcomes; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.odds_snapshots
    ADD CONSTRAINT fk_odds_snapshots_outcome_id_outcomes FOREIGN KEY (outcome_id) REFERENCES public.outcomes(id) ON DELETE CASCADE;


--
-- Name: outcomes fk_outcomes_market_id_markets; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT fk_outcomes_market_id_markets FOREIGN KEY (market_id) REFERENCES public.markets(id) ON DELETE CASCADE;


--
-- Name: predictions fk_predictions_match_id_matches; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT fk_predictions_match_id_matches FOREIGN KEY (match_id) REFERENCES public.matches(id) ON DELETE CASCADE;


--
-- Name: predictions fk_predictions_model_version_id_model_versions; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT fk_predictions_model_version_id_model_versions FOREIGN KEY (model_version_id) REFERENCES public.model_versions(id) ON DELETE RESTRICT;


--
-- Name: predictions fk_predictions_outcome_id_outcomes; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT fk_predictions_outcome_id_outcomes FOREIGN KEY (outcome_id) REFERENCES public.outcomes(id) ON DELETE SET NULL;


--
-- Name: predictions fk_predictions_reference_snapshot_id_odds_snapshots; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT fk_predictions_reference_snapshot_id_odds_snapshots FOREIGN KEY (reference_snapshot_id) REFERENCES public.odds_snapshots(id) ON DELETE SET NULL;


--
-- Name: predictions fk_predictions_scan_id_scans; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT fk_predictions_scan_id_scans FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: predictions fk_predictions_tradeable_snapshot_id_odds_snapshots; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT fk_predictions_tradeable_snapshot_id_odds_snapshots FOREIGN KEY (tradeable_snapshot_id) REFERENCES public.odds_snapshots(id) ON DELETE SET NULL;


--
-- Name: saved_fixtures fk_saved_fixtures_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_fixtures
    ADD CONSTRAINT fk_saved_fixtures_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: scans fk_scans_model_version_id_model_versions; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT fk_scans_model_version_id_model_versions FOREIGN KEY (model_version_id) REFERENCES public.model_versions(id) ON DELETE RESTRICT;


--
-- Name: scans fk_scans_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT fk_scans_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: team_aliases fk_team_aliases_team_id_teams; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_aliases
    ADD CONSTRAINT fk_team_aliases_team_id_teams FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: teams fk_teams_competition_id_competitions; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT fk_teams_competition_id_competitions FOREIGN KEY (competition_id) REFERENCES public.competitions(id) ON DELETE SET NULL;


--
-- Name: user_feedback fk_user_feedback_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_feedback
    ADD CONSTRAINT fk_user_feedback_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_preferences fk_user_preferences_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT fk_user_preferences_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wallet_transactions fk_wallet_transactions_parent_transaction_id_wallet_tra_5fb2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT fk_wallet_transactions_parent_transaction_id_wallet_tra_5fb2 FOREIGN KEY (parent_transaction_id) REFERENCES public.wallet_transactions(id) ON DELETE RESTRICT;


--
-- Name: wallet_transactions fk_wallet_transactions_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT fk_wallet_transactions_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict IXkcCBDhDMjuvYup8hJ0P8fIuWcAhG0mHwUO615A86Jj0gENoqTmPkbvgFHDECH

